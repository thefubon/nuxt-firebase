<template>
  <div class="container mx-auto my-16">
    <h3 class="text-2xl font-bold mb-4">Registered Users</h3>
    <table class="table-auto border-separate border border-green-800 w-full">
      <thead>
        <tr>
          <th class="border border-green-600">№</th>
          <th  class="border border-green-600">Date</th>
          <th  class="border border-green-600">first</th>
          <th  class="border border-green-600">Last</th>
          <th  class="border border-green-600">code</th>
          <th  class="border border-green-600">Phone</th>
          <th  class="border border-green-600">Country</th>
          <th  class="border border-green-600">email</th>
          <th  class="border border-green-600">gendere</th>
          <th  class="border border-green-600">utmSource</th>
          <th  class="border border-green-600">utmMedium</th>
          <th  class="border border-green-600">utmTerm</th>
          <th  class="border border-green-600">utmContent</th>
          <th  class="border border-green-600">utmCampaign</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td class="border border-green-600">3</td>
          <td class="border border-green-600">24.12.2021</td>
          <td class="border border-green-600">User</td>
          <td class="border border-green-600">Bot</td>
          <td class="border border-green-600">+7</td>
          <td class="border border-green-600">903 134-43-54</td>
          <td class="border border-green-600">Russia</td>
          <td class="border border-green-600">hellow@site.com</td>
          <td class="border border-green-600">Male</td>
          <td class="border border-green-600">website_com</td>
          <td class="border border-green-600">news</td>
          <td class="border border-green-600">name_conference</td>
          <td class="border border-green-600">article</td>
          <td class="border border-green-600">moscow</td>
        </tr>
        <tr>
          <td class="border border-green-600">2</td>
          <td class="border border-green-600">24.12.2021</td>
          <td class="border border-green-600">User</td>
          <td class="border border-green-600">Bot</td>
          <td class="border border-green-600">+7</td>
          <td class="border border-green-600">903 134-43-54</td>
          <td class="border border-green-600">Russia</td>
          <td class="border border-green-600">hellow@site.com</td>
          <td class="border border-green-600">Male</td>
          <td class="border border-green-600">website_com</td>
          <td class="border border-green-600">news</td>
          <td class="border border-green-600">name_conference</td>
          <td class="border border-green-600">article</td>
          <td class="border border-green-600">moscow</td>
        </tr>
        <tr>
          <td class="border border-green-600">1</td>
          <td class="border border-green-600">22.12.2021</td>
          <td class="border border-green-600">User</td>
          <td class="border border-green-600">Bot</td>
          <td class="border border-green-600">+7</td>
          <td class="border border-green-600">903 134-43-54</td>
          <td class="border border-green-600">Russia</td>
          <td class="border border-green-600">hellow@site.com</td>
          <td class="border border-green-600">Male</td>
          <td class="border border-green-600">website_com</td>
          <td class="border border-green-600">news</td>
          <td class="border border-green-600">name_conference</td>
          <td class="border border-green-600">article</td>
          <td class="border border-green-600">moscow</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
