<template>
  <div>
    <client-only>
      <nav class="navbar navbar-expand navbar-light bg-light">
        <div class="container-fluid">
          <nuxt-link class="navbar-brand" to="/">Nuxt Form</nuxt-link>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <nuxt-link
                  class="nav-link"
                  :class="{ active: this.$route.path === '/' }"
                  exact
                  aria-current="page"
                  to="/"
                  >Form</nuxt-link
                >
              </li>
              <li class="nav-item">
                <nuxt-link
                  class="nav-link"
                  :class="{ active: this.$route.path === '/data' }"
                  exact
                  aria-current="page"
                  to="/data"
                  >Data</nuxt-link
                >
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <Nuxt />
    </client-only>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
