<template>
  <div>
    <div class="text-center mt-10">
      <a
        class="underline "
        href="https://github.com/thefubon/nuxt-form"
        target="_blank"
      >
        View files on GitHub
      </a>
    </div>
    <Form />
    <!-- <FormData /> -->
  </div>
</template>

<script>
export default {
  layout: "default"
};
</script>
