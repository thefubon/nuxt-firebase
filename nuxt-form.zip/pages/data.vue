<template>
  <div class="container mx-auto my-16">
    <h3 class="text-2xl font-bold mb-4">Registered Users</h3>
    <div
      v-if="loading"
      class="spinner-border"
      style="width: 2rem; height: 2rem"
      role="status"
    >
      <span class="visually-hidden">Loading...</span>
    </div>
    <table v-else class="table table-hover  table-striped">
      <thead>
        <tr>
          <th>№</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Code</th>
          <th>Phone</th>
          <th>Country</th>
          <th>Email</th>
          <th>Gendere</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(item, index) in items" :key="index">
          <td>{{ index + 1 }}</td>
          <td>{{ item.firstName }}</td>
          <td>{{ item.LastName }}</td>
          <td>{{ item.code }}</td>
          <td>{{ item.phone }}</td>
          <td>{{ item.country }}</td>
          <td>{{ item.email }}</td>
          <td>{{ item.gendere }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import { db } from "~/plugins/firebase";
import { getDocs, collection } from "firebase/firestore";
export default {
  data: () => ({
    items: [],
    loading: true
  }),
  mounted() {
    this.setInitialize();
  },
  methods: {
    async setInitialize() {
      try {
        this.loading = true;
        const docs = await getDocs(collection(db, "users"));
        docs.forEach(doc => this.items.push(doc.data()));
        this.loading = false;
      } catch (e) {
        console.log(e);
        this.loading = false;
      }
    }
  }
};
</script>
